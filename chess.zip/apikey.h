#ifndef APIKEY_H
#define APIKEY_H

#include <string>
const std::string API_KEY = "sk-proj-EaPnzTgg2DJPau59c7LLT3BlbkFJAXaPfNYPyon6etmbB3uf";

#endif
